package com.oms.entity;



public class Clothing extends Product {
    // Additional attributes for Clothing
    private String size;
    private String color;

    // Constructors
    public Clothing() {
        // Default constructor
    }

    public Clothing(int productId, String productName, String description, double price,
                    int quantityInStock, String type, String size, String color) {
        super(productId, productName, description, price, quantityInStock, type);
        this.size = size;
        this.color = color;
    }

    // Getters and Setters for Clothing-specific attributes
    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // toString method to represent the Clothing object as a string
    @Override
    public String toString() {
        return "Clothing{" +
                "productId=" + getProductId() +
                ", productName='" + getProductName() + '\'' +
                ", description='" + getDescription() + '\'' +
                ", price=" + getPrice() +
                ", quantityInStock=" + getQuantityInStock() +
                ", type='" + getType() + '\'' +
                ", size='" + size + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}
