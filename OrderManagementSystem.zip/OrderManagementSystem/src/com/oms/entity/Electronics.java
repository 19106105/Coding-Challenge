package com.oms.entity;



public class Electronics extends Product {
    // Additional attributes for Electronics
    private String brand;
    private int warrantyPeriod;

    // Constructors
    public Electronics() {
        // Default constructor
    }

    public Electronics(int productId, String productName, String description, double price,
                       int quantityInStock, String type, String brand, int warrantyPeriod) {
        super(productId, productName, description, price, quantityInStock, type);
        this.brand = brand;
        this.warrantyPeriod = warrantyPeriod;
    }

    // Getters and Setters for Electronics-specific attributes
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(int warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }

    // toString method to represent the Electronics object as a string
    @Override
    public String toString() {
        return "Electronics{" +
                "productId=" + getProductId() +
                ", productName='" + getProductName() + '\'' +
                ", description='" + getDescription() + '\'' +
                ", price=" + getPrice() +
                ", quantityInStock=" + getQuantityInStock() +
                ", type='" + getType() + '\'' +
                ", brand='" + brand + '\'' +
                ", warrantyPeriod=" + warrantyPeriod +
                '}';
    }
}
