package com.oms.main;

import java.util.List;
import java.util.Scanner;

import com.oms.dao.IOrderManagementRepository;
import com.oms.dao.OrderProcessor;
import com.oms.entity.Product;
import com.oms.entity.User;
import com.oms.exception.OrderNotFoundException;
import com.oms.exception.UserNotFoundException;

public class OrderManagement {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IOrderManagementRepository orderProcessor = new OrderProcessor();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Cancel Order");
            System.out.println("4. Get All Products");
            System.out.println("5. Get Orders by User");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    createUser(scanner, orderProcessor);
                    break;
                case 2:
                    createProduct(scanner, orderProcessor);
                    break;
                case 3:
                    cancelOrder(scanner, orderProcessor);
                    break;
                case 4:
                    getAllProducts(orderProcessor);
                    break;
                case 5:
                    getOrdersByUser(scanner, orderProcessor);
                    break;
                case 6:
                    System.out.println("Exiting the Order Management System. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void createUser(Scanner scanner, IOrderManagementRepository orderProcessor) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter role (Admin/User): ");
        String role = scanner.nextLine();

        User user = new User(userId, 0, username, password, role); // Assuming product ID is not needed during user creation
        orderProcessor.createUser(user);
        System.out.println("User created successfully.");
    }

    private static void createProduct(Scanner scanner, IOrderManagementRepository orderProcessor) {
        System.out.print("Enter admin user ID: ");
        int adminUserId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Assuming the admin user ID is required for creating a product
        User adminUser = new User(adminUserId, 0, "", "", "Admin");

        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();

        System.out.print("Enter product description: ");
        String description = scanner.nextLine();

        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter quantity in stock: ");
        int quantityInStock = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter product type (Electronics/Clothing): ");
        String type = scanner.nextLine();

        Product product = new Product(productId, productName, description, price, quantityInStock, type);

        try {
            orderProcessor.createProduct(adminUser, product);
            System.out.println("Product created successfully.");
        } catch (UserNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void cancelOrder(Scanner scanner, IOrderManagementRepository orderProcessor) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        try {
            orderProcessor.cancelOrder(userId, orderId);
            System.out.println("Order canceled successfully.");
        } catch (UserNotFoundException | OrderNotFoundException e) {
            System.out.println("Error: " + ( e).getMessage());
        }
    }

    private static void getAllProducts(IOrderManagementRepository orderProcessor) {
        List<Product> products = orderProcessor.getAllProducts();
        System.out.println("All Products:");
        for (Product product : products) {
            System.out.println(product);
        }
    }

    private static void getOrdersByUser(Scanner scanner, IOrderManagementRepository orderProcessor) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        User user = new User(userId, 0, "", "", ""); // Create a dummy user with only the ID for the purpose of fetching orders

        List<Product> orders = orderProcessor.getOrderByUser(user);
        System.out.println("Orders by User:");
        for (Product order : orders) {
            System.out.println(order);
        }
    }

}
