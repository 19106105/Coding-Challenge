package com.oms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.oms.entity.Product;
import com.oms.entity.User;
import com.oms.exception.OrderNotFoundException;
import com.oms.exception.UserNotFoundException;
import com.oms.util.DBUtil;

public class OrderProcessor implements IOrderManagementRepository {

    private List<Product> productList; 
    private List<User> userList;       

    public OrderProcessor() {
        this.productList = new ArrayList<>();
        this.userList = new ArrayList<>();
    }
    @Override
    public void createOrder(User user, List<Product> products) {
        try (Connection connection = DBUtil.getDBConn()) {
            // Insert user details into the user table
            createUser(user);

            // Insert product details into the product table
            for (Product product : products) {
                createProduct(product);
            }

            // Placeholder logic to insert order details into the order table
            // ...

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try (Connection connection = DBUtil.getDBConn()) {
            // Placeholder logic to cancel the order in the order table
            // ...

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }
    }

    @Override
    public void createProduct(User adminUser, Product product) throws UserNotFoundException {
        try (Connection connection = DBUtil.getDBConn()) {
            // Check if the admin user exists
            /*if (!isUserExistInDatabase(connection, adminUser.getUserId())) {
                throw new UserNotFoundException("Admin user not found in the database.");
            }*/

            // Insert product details into the product table
            createProduct(product);

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }
    }

    @Override
    public void createUser(User user) {
        try (Connection connection = DBUtil.getDBConn()) {
            // Insert user details into the user table
            createUserInDatabase(user);

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        try (Connection connection = DBUtil.getDBConn()) {
            // Retrieve all products from the product table
            String query = "SELECT * FROM ordermanagementsystem.product";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    Product product = new Product(
                            resultSet.getInt("product_id"),
                            resultSet.getString("productName"),
                            resultSet.getString("description"),
                            resultSet.getDouble("price"),
                            resultSet.getInt("quantityInStock"),
                            resultSet.getString("type")
                    );
                    productList.add(product);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }
        return productList;
    }

    @Override
    public List<Product> getOrderByUser(User user) {
        List<Product> orderList = new ArrayList<>();
        try (Connection connection = DBUtil.getDBConn()) {
            // Placeholder logic to retrieve products ordered by a specific user from the order table
            // ...

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }
        return orderList;
    }

    @Override
    public boolean isUserExistInDatabase(int userId) {
        // Placeholder logic to check if a user exists in the database
        return false;
    }

    @Override
    public boolean isOrderExistInDatabase(int userId, int orderId) {
        // Placeholder logic to check if an order exists in the database
        return false;
    }

    // Helper method to check if a user exists in the user table
    private boolean isUserExistInDatabase(Connection connection, int userId) throws SQLException {
        String query = "SELECT * FROM ordermanagementsystem.user WHERE userId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next(); // Returns true if user exists, false otherwise
            }
        }
    }

    // Helper method to create a user in the user table
    private void createUserInDatabase(User user) throws SQLException {
        try (Connection connection = DBUtil.getDBConn();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO ordermanagementsystem.user (user_id, userId, username, password, role) VALUES (?, ?, ?, ?, ?)"
             )) {

            preparedStatement.setInt(1, user.getUserId());
            preparedStatement.setInt(2, user.getUserId());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setString(5, user.getRole());

            preparedStatement.executeUpdate();
        }
    }

    // Helper method to create a product in the product table
    private void createProduct(Product product) throws SQLException {
        try (Connection connection = DBUtil.getDBConn();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO ordermanagementsystem.product (product_id, productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?, ?)"
             )) {

            preparedStatement.setInt(1, product.getProductId());
            preparedStatement.setString(2, product.getProductName());
            preparedStatement.setString(3, product.getDescription());
            preparedStatement.setDouble(4, product.getPrice());
            preparedStatement.setInt(5, product.getQuantityInStock());
            preparedStatement.setString(6, product.getType());

            preparedStatement.executeUpdate();
        }
    }
}

